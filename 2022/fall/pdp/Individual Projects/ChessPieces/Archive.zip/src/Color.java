
/**
 * Color of any ChessPiece.It has only two options either white or black.
 */
public enum Color {
  WHITE, BLACK
}
